# CHANGELOG v1.3.0
## General
- Infested Deepslate can now be rotated.
- Updated for 1.17